export const faqData = [
    {
        questionKey: "faq.questions.1.question",
        answerKey: "faq.questions.1.answer",
        isOpen: false
      },
      {
        questionKey: "faq.questions.2.question",
        answerKey: "faq.questions.2.answer",
        isOpen: false
      },
      {
        questionKey: "faq.questions.3.question",
        answerKey: "faq.questions.3.answer",
        isOpen: false
      },
      {
        questionKey: "faq.questions.4.question",
        answerKey: "faq.questions.4.answer",
        isOpen: false
      },
      {
        questionKey: "faq.questions.5.question",
        answerKey: "faq.questions.5.answer",
        isOpen: false
      }
];
